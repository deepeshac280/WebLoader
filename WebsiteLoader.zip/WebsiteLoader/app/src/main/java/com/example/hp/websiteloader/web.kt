package com.example.hp.websiteloader

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.android.synthetic.main.activity_web.*
import java.util.*

var wv1: WebView? =null
class web : AppCompatActivity() {
    override fun onBackPressed() {
        super.onBackPressed()
        val intent=Intent(applicationContext,MainActivity::class.java)
        startActivity(intent)
    }
    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)
         wv1=findViewById<WebView>(R.id.webview)
new()
    }
    fun new():Int
    {
        var site="http://www.tutorialspoint.com"

        wv1?.webViewClient= object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {

                view.loadUrl("javascript:(function() { " +
                        "var head = document.getElementsByClassName('main')[0].style.display='none'; " +
                        "var head = document.getElementsByClassName('inner')[0].style.display='none'; " +
                        "})()")
            }
        }
        wv1?.settings?.javaScriptEnabled=true
        wv1?.settings?.loadsImagesAutomatically=true
        wv1?.loadUrl(site)

    return 1
    }
}


