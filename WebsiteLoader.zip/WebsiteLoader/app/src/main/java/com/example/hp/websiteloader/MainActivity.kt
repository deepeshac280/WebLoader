package com.example.hp.websiteloader

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var fa:Activity=this@MainActivity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.INTERNET)!=
        PackageManager.PERMISSION_GRANTED)
{
    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.INTERNET),1234)
}
        else
    {
        submit.setOnClickListener({
            if(website.text.isNotEmpty())
            {
                var cls=web()
                var a=cls.new()
                progressbar1.visibility= View.VISIBLE
                val intent=Intent(applicationContext,web::class.java)
                if(a==1)
                startActivity(intent)
            }
        })
    }
}
    @SuppressLint("MissingPermission")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode)
        {
            1234->{
                if(grantResults.size>0&&
                        grantResults[0]==PackageManager.PERMISSION_GRANTED)
                {
                    Toast.makeText(this@MainActivity,"We are now Good to Go", Toast.LENGTH_SHORT).show()
                }
                else
                    Toast.makeText(this@MainActivity,"Permission Denied ", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
